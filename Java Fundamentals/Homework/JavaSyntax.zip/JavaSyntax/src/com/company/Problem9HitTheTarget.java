package com.company;

/**
 * Created by MartinLachev on 3/23/2016.
 */
public class Problem9HitTheTarget {
    public static void main(String[] args) {

    }
}
