package com.company;

/**
 * Created by User on 6.3.2016 г..
 */
public class PrintCharecters {
    public static void main(String[] args) {
        for (char i = (int)97; i < 123; i++) {
            System.out.print(i + " ");

        }
    }

}

