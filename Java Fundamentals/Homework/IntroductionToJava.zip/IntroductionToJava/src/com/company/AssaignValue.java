package com.company;

public class AssaignValue {

    public static void main(String[] args) {

        byte first = 127;
        short second = 32767;
        int third = 2000000000;
        long fourth = 919827112351L;
        char fifth = 'c';
        boolean sixth = false;
        float seventh = 0.5f;
        double eight = 0.1234567891011;
        String nine = "Palo Alto, CA";
        short last = (short) 32768;


        System.out.println(first);
        System.out.println(second);
        System.out.println(third);
        System.out.println(fourth);
        System.out.println(fifth);
        System.out.println(sixth);
        System.out.println(seventh);
        System.out.println(eight);
        System.out.println(nine);
        System.out.println(last);

    }
}
