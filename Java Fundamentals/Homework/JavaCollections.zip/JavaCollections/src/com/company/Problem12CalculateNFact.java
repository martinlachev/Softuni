package com.company;

/**
 * Created by MartinLachev on 3/30/2016.
 */
public class Problem12CalculateNFact {
    public static void main(String[] args) {

    }
}
