/**
 * Created by MartinLachev on 6/24/2016.
 */
function showText() {
   document.getElementById("text").style.display = 'inline';
    document.getElementById("more").style.display = 'none';

}